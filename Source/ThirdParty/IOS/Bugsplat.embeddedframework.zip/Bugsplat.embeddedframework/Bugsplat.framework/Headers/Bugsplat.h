//
//  Bugsplat.h
//  Bugsplat
//
//  Created by Geoff Raeder on 5/26/21.
//

#import <Foundation/Foundation.h>

//! Project version number for Bugsplat.
FOUNDATION_EXPORT double BugsplatVersionNumber;

//! Project version string for Bugsplat.
FOUNDATION_EXPORT const unsigned char BugsplatVersionString[];

#import <Bugsplat/BugsplatStartupManager.h>
#import <Bugsplat/BugsplatStartupManagerDelegate.h>
#import <Bugsplat/BugsplatAttachment.h>


